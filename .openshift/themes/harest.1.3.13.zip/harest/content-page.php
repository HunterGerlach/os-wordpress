<?php
/**
 * The Page content template file.
 *
 * @package ThinkUpThemes
 */
?>

		<?php the_content(); ?>

