<p><?php _e( 'This theme comes with special option. This option allow you to use custom css. With custom css you can customize your web site to your needs.', 'tempo' ); ?></p>
<p><?php _e( 'To use it go to Admin Dashboard', 'tempo' ); ?></p>
<p><strong><?php _e( 'Appearance &rsaquo; Customize &rsaquo; Others &rsaquo; Custom CSS.', 'tempo' ); ?></strong></p>
<p><?php _e( 'You can use it for multiple case, just is need to add your custom css.', 'tempo' ); ?></p>