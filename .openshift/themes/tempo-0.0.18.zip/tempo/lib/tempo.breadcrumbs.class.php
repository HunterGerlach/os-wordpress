<?php
if( !class_exists( 'tempo_breadcrumbs' ) ){

class tempo_breadcrumbs
{
	static function home()
    {
        $rett  = '<li id="home-text">';
        $rett .= '<a href="' . esc_url( home_url( '/' ) ) . '" title="' . esc_attr( tempo_options::get( 'breadcrumbs-home-description' ) ) . '">';
        $rett .= '<i class="tempo-icon-home-5"></i> <span>' . tempo_options::get( 'breadcrumbs-home-text' ) . '</span>';
        $rett .= '</a>';
        $rett .= '</li>';

        return $rett;
    }

    static function categories( $c_id )
	{
		$rett = '';

		$c = get_category( $c_id );

		if( isset( $c -> category_parent ) && $c -> category_parent > 0 ){
			$rett .= self::categories( $c -> category_parent );
		}

		$category_link = get_category_link( $c -> term_id );

		if( is_wp_error( $category_link ) ){
			return '';
		}

		if( is_category( $c -> term_id ) ){
			$rett .= '<li>' . esc_html( $c -> name ) . '</li>';
		}
		else{
			$rett .= '<li>';
			$rett .= '<a href="' . esc_url( $category_link ) . '" title="' . sprintf( __( 'See articles from category - %s' , 'tempo' ), esc_attr( $c -> name ) ) . '">' . $c -> name . '</a>';
			$rett .= '</li>';
		}

		return $rett;
	}

	static function pages( $p )
	{
        $rett = '';

        if( isset( $p -> post_parent ) && $p -> post_parent > 0 ){
            $parent = get_post( $p -> post_parent );
            $rett .= self::pages( $parent );
        }

        if( !is_page( $p -> ID  ) ){
            $rett .= '<li>';
            $rett .= '<a href="' . esc_url( get_permalink( $p ) ) . '" title="' . esc_attr( get_the_title( $p ) ) . '">' .  get_the_title( $p ) . '</a>';
            $rett .= '</li>';
        }

        return $rett;
    }

    static function count( $query )
    {
        $query = apply_filters( 'tempo_breadcrumbs_counter_query', $query );
        
    	$label = _n( 'One Article' , '%s Articles' ,  absint( $query -> found_posts ) , 'tempo' );
        return '<span class="counter-wrapper">' . sprintf( $label , '<span class="counter">' . number_format_i18n( absint( $query -> found_posts ) ) . '</span>' ) . '</span>';
    }
}

}   /* END IF CLASS EXISTS */
?>